# Thank you for purchasing the premium features for Astrogency!

## To install:

- Replace `/src/actions/index.ts` with `actions/index.ts`.
- Replace all components in `/src/components/bloks/premium` with the content in the premium folder.

